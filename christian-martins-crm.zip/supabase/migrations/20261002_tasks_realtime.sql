-- ==============================================================================
-- CHRISTIAN MARTINS CRM - FASE 4.3: HABILITAÇÃO DO SUPABASE REALTIME PARA TASKS
-- File: supabase/migrations/20261002_tasks_realtime.sql
-- ==============================================================================

-- Adiciona a tabela public.tasks à publicação de Realtime do Supabase
-- Isso permite o envio de eventos INSERT, UPDATE e DELETE via WebSockets
ALTER PUBLICATION supabase_realtime ADD TABLE public.tasks;
