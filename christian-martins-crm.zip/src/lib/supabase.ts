import { createClient, SupabaseClient } from '@supabase/supabase-js';
import type { Database } from '../types/supabase';

const isValidUrl = (url: string | undefined | null): boolean => {
  if (!url || typeof url !== 'string') return false;
  try {
    const parsed = new URL(url.trim());
    return (parsed.protocol === 'http:' || parsed.protocol === 'https:') && parsed.hostname.length > 0;
  } catch {
    return false;
  }
};

// Suporte tanto para ambiente Vite (import.meta.env) quanto Next.js/Vercel (process.env / NEXT_PUBLIC_)
const getEnvVar = (viteKey: string, nextKey: string): string => {
  let val: string | undefined = undefined;

  try {
    if (typeof import.meta !== 'undefined' && import.meta.env) {
      val = import.meta.env[viteKey] || import.meta.env[nextKey];
    }
  } catch {
    // ignore
  }

  if (!val) {
    try {
      if (typeof process !== 'undefined' && process.env) {
        val = process.env[viteKey] || process.env[nextKey];
      }
    } catch {
      // ignore
    }
  }

  return val && typeof val === 'string' ? val.trim() : '';
};

// URL e chave do Supabase obtidas exclusivamente das variáveis de ambiente
export const supabaseUrl: string = getEnvVar('VITE_SUPABASE_URL', 'NEXT_PUBLIC_SUPABASE_URL');
export const supabaseAnonKey: string = getEnvVar('VITE_SUPABASE_ANON_KEY', 'NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY');

export const isSupabaseConfigured = (): boolean => {
  const configured = isValidUrl(supabaseUrl) && Boolean(supabaseAnonKey);
  if (!configured) {
    console.warn("⚠️ Supabase configuration missing or invalid. CRM functionality disabled.");
  }
  return configured;
};

// Instância singleton do cliente Supabase tipado
// Se a configuração estiver ausente, usamos uma URL segura que não lançará exceção de parse de URL.
// Componentes devem sempre verificar isSupabaseConfigured() antes de usar a instância 'supabase'.
const clientUrl = isValidUrl(supabaseUrl) ? supabaseUrl : 'https://unconfigured.local';
const clientKey = (supabaseAnonKey && supabaseAnonKey.length > 0) ? supabaseAnonKey : 'unconfigured-key';

export const supabase: SupabaseClient<Database> = createClient<Database>(
  clientUrl,
  clientKey,
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
    },
  }
);
